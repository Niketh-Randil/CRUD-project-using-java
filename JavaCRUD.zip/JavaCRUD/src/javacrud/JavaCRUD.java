
package javacrud;


public class JavaCRUD {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System_login start=new System_login();
        start.setVisible(true);
    }
    
}
